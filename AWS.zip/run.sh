
FLASK_APP=HealthiCountyR/app.py flask run